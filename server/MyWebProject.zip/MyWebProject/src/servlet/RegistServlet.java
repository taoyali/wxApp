package servlet;

import DAO.UserInfo;
import db.dbUser;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Created by taoyali on 2017/9/3.
 */
@WebServlet(name = "RegistServlet")
public class RegistServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String pwd = request.getParameter("pwd");
        String email = request.getParameter("email");
        UserInfo userInfo = new UserInfo(name, pwd, email);
        dbUser dbUser = new dbUser();
        String registStatus = new String();
        try {
            Boolean addResult = dbUser.addUser(userInfo);
            if (addResult) {
                registStatus = "注册成功";
            } else  {
                registStatus = "注册失败";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter pw = response.getWriter();
        String docType = "<!DOCTYPE html> \n";
        pw.println(docType +
                "<html>\n" +
                "<head><title>" + "注册" + "</title></head>\n" +
                "<body bgcolor=\"#f0f0f0\">\n" +
                "<h1 align=\"center\">" + registStatus + "</h1>\n" +
                "</ul>\n" +
                "</body></html>");
    }
}
