package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
/**
 * Created by taoyali on 2017/9/3.
 */
public class dbConnect {
    private static String driver = "com.mysql.jdbc.Driver";
    private static String url = "jdbc:mysql://localhost:3306/MyBlog";
    private static String user = "root";
    private static String password = "";
    private Connection dbConnection = null;

    public Connection getDbConnection() {
        return dbConnection;
    }

    public dbConnect() {
        super();
        try {
            //加载驱动程序
            Class.forName(driver);
            dbConnection = DriverManager.getConnection(url, user, password);
            if (!dbConnection.isClosed()) {
                System.out.println(" Succeeded connecting to the Database! ");
            }
        } catch (ClassNotFoundException e) {
            //数据库驱动类异常处理
            System.out.println("Sorry,can`t find the Driver!");
            e.printStackTrace();
        } catch (SQLException e) {
            //数据库连接失败异常处理
            e.printStackTrace();
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }
    }

    public void connectSql(String driver, String url, String user, String password) {
        Connection connection;
        String conDriver = driver != null ? driver : "com.sql.jdbc.Driver";
        String conUrl = url != null ? url : "jdbc:mysql://localhost:3306/MyBlog";
        String conUser = user != null ? user : "root";
        String conPassword = password != null ? password : "";
        try {
            //加载驱动程序
            Class.forName(conDriver);
            connection = DriverManager.getConnection(conUrl, conUser, conPassword);
            if (!connection.isClosed()) {
                System.out.println(" Succeeded connecting to the Database! ");
                return;
            }
            dbConnection = connection;
        } catch (ClassNotFoundException e) {
            //数据库驱动类异常处理
            System.out.println("Sorry,can`t find the Driver!");
            e.printStackTrace();
        } catch (SQLException e) {
            //数据库连接失败异常处理
            e.printStackTrace();
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }
    }
    public void closeSql() {

            try {
                if (!dbConnection.isClosed()) {
                    dbConnection.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
    }
}
