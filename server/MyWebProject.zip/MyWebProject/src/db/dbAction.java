package db;

import DAO.UserInfo;
import java.util.*;
/**
 * Created by taoyali on 2017/9/3.
 */
public interface dbAction {
    public List<UserInfo> selectByName(String userName) throws Exception;
    public List<UserInfo> selectByName(String userName, String password) throws Exception;
    public boolean addUser(UserInfo user) throws Exception;
}
