package db;

import DAO.UserInfo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Created by taoyali on 2017/9/3.
 */
public class dbUser implements dbAction {
    private Connection connection;
    private PreparedStatement pStatement;

    public dbUser() {
        super();
        dbConnect dbConnect = new dbConnect();
        connection = dbConnect.getDbConnection();
    }
    @Override
    public List<UserInfo> selectByName(String userName) throws Exception {
        List<UserInfo> userInfos = new ArrayList<UserInfo>();
        String sql = "select * from  users where name = ?";
        this.pStatement = this.connection.prepareStatement(sql);
        this.pStatement.setString(1, userName);
        ResultSet rs = this.pStatement.executeQuery();
        while (rs.next()) {
            UserInfo userInfo = new UserInfo();
            userInfo.setId(rs.getInt(1));
            userInfo.setName(rs.getNString(2));
            userInfo.setPassword(rs.getNString(3));
            userInfos.add(userInfo);
        }
        return userInfos;
    }

    @Override
    public List<UserInfo> selectByName(String userName, String password) throws Exception {
        List<UserInfo> userInfos = new ArrayList<UserInfo>();
        String sql = "select * from users where name = ? and pwd = ?";
        this.pStatement = this.connection.prepareStatement(sql);
        this.pStatement.setString(1, userName);
        this.pStatement.setString(2, password);
        ResultSet rs = this.pStatement.executeQuery();
        while (rs.next()) {
            UserInfo userInfo = new UserInfo();
            userInfo.setId(rs.getInt(1));
            userInfo.setName(rs.getNString(2));
            userInfo.setPassword(rs.getNString(3));
            userInfos.add(userInfo);
            break;
        }
        return userInfos;
    }

    @Override
    public boolean addUser(UserInfo user) throws Exception {
        String sql = "insert into users (name, pwd) values (?,?)";
        this.pStatement = this.connection.prepareStatement(sql);
        this.pStatement.setString(1,user.getName());
        this.pStatement.setString(2,user.getPassword());
//        this.pStatement.setString(3,user.getEmail());
        sql = "insert into users (name, pwd, email) values ( 'zhangqi', 'taoyali', null)";
        return this.pStatement.executeUpdate(sql) > 0;
    }
}
