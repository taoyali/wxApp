package DB;

/**
 * Created by taoyali on 2018/1/26.
 */
public class DBError {

}
